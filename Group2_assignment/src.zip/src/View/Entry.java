/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package View;

import controller.CustomerManagement;
import controller.RoomManagement;

/**
 *
 * @author PC
 */
public class Entry {
    public static void main(String[] args) {
        RoomManagement r = new RoomManagement();
        r.run();
    }
}